
let setRoot = document.documentElement.style;


let rootMap = new Map();

rootMap.set('--color-cyan','#8b7bf5');
rootMap.set('--color-dark-1','#191727');
rootMap.set('--color-dark-2','#282737');
rootMap.set('--color-dark-3','#1d1d29');
rootMap.set('--color-red','crimson');
rootMap.set('--color-blue','#3f00a8');

SetRootProperty(rootMap);



function SetRootProperty(map){
    for (const [k,v] of map) {
        setRoot.setProperty(k,v);
    }
}



