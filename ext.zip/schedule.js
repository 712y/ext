
let rightBlock = document.createElement('div');
rightBlock.style.display = 'grid';
rightBlock.style.placeItems = 'center';
let block = document.createElement('div');
block.style.width = '100%';
if(IsDarkTheme()){
    block.style.color = 'var(--color-light-2)';
    block.style.backgroundColor = 'var(--color-dark-2)';
}else{
    block.style.color = 'var(--color-dark-2)';
    block.style.backgroundColor = 'var(--color-light-1)';
}
block.style.borderRadius = '8px';
block.style.display = 'flex';
block.style.flexDirection = 'column';
block.style.justifyContent = 'center'
block.style.padding = '10px 5px 15px'
block.style.alignItems = 'center'
block.style.gap = '10px';
block.style.textDecoration = 'none';
block.style.overflow = 'hidden';
block.style.position = 'relative';
block.style.minHeight = '100px';
block.style.maxWidth = '500px';
block.style.userSelect = 'none'

block.className = 'timeBlock';
block.ondblclick = (e) => {
    scroll2element(document.getElementById('cur'))
};


let leftTime = document.createElement('div');
leftTime.style.display = 'grid';
leftTime.style.placeContent = 'center';
leftTime.style.width = '100%';
leftTime.style.fontSize = '40px';

let predmet = document.createElement('div');
predmet.style.display = 'grid';
predmet.style.placeContent = 'center';
predmet.style.width = '100%';
predmet.style.fontSize = '15px';


let progressBar = document.createElement('div');
progressBar.style.height = '5px';
progressBar.style.width = '100%'
progressBar.style.position = 'absolute';
progressBar.style.bottom = '0';
progressBar.style.backgroundColor = 'transparent';
progressBar.style.boxShadow = '0 0 10px transparent';
progressBar.style.transition = 'all 1s ease-in-out';


let tsInput = document.createElement('input');
tsInput.type = 'number';
tsInput.style.textAlign = 'center';
tsInput.style.fontSize = '20px';
//tsInput.style.marginBottom = '10px';
tsInput.style.width = '50%';
tsInput.onchange = () => {
    localStorage.setItem('ts',tsInput.value);
    ts = +tsInput.value;
}

let otsw = document.createElement('div');
otsw.style.position = 'absolute';
otsw.style.bottom = '15px';
otsw.style.right = '19px';
otsw.style.width = '20px';
otsw.style.height = '20px';
otsw.style.border = '2px solid transparent';

if(IsDarkTheme()){
    otsw.style.borderBottomColor = 'var(--color-light-1)';
    otsw.style.borderRightColor = 'var(--color-light-1)';
}else{
    otsw.style.borderBottomColor = 'var(--color-dark-2)';
    otsw.style.borderRightColor = 'var(--color-dark-2)';
}

otsw.style.transform = 'rotateZ(45deg)';
otsw.style.transition = 'all 300ms ease-in-out';
let otswIo = false;
otsw.onclick = () => {
    if(otswIo){
        otsw.style.transform = 'rotateZ(-135deg) translate(-50%,-50%)';
        tsInput.value = +localStorage.getItem('ts') || 0;
        block.append(tsInput);
    }else{
        otsw.style.transform = 'rotateZ(45deg)';
        tsInput.remove();
    }
    otswIo = !otswIo;
}
let fs = false;
let fsB = document.createElement('div');
fsB.style.position = 'absolute';
fsB.style.top = '15px';
fsB.style.right = '15px';
fsB.style.width = '28px';
fsB.style.height = '28px';
fsB.style.display = 'grid';
fsB.style.gridTemplateColumns = '1fr 1fr';
fsB.style.gap = '5px';
fsB.style.transition = 'all 300ms ease-in-out';
fsB.onclick = fullSrcreen;

let angleLT = document.createElement('div');
angleLT.style.width = '100%';
angleLT.style.height = '100%';
if(IsDarkTheme()){
    angleLT.style.borderLeft = '2px solid var(--color-light-1)';
    angleLT.style.borderTop = '2px solid var(--color-light-1)';
}else{
    angleLT.style.borderLeft = '2px solid var(--color-dark-2)';
    angleLT.style.borderTop = '2px solid var(--color-dark-2)';
}

let angleRT = document.createElement('div');
angleRT.style.width = '100%';
angleRT.style.height = '100%';
if(IsDarkTheme()){
    angleRT.style.borderRight = '2px solid var(--color-light-1)';
    angleRT.style.borderTop = '2px solid var(--color-light-1)';
}else{
    angleRT.style.borderRight = '2px solid var(--color-dark-2)';
    angleRT.style.borderTop = '2px solid var(--color-dark-2)';
}

let angleLB = document.createElement('div');
angleLB.style.width = '100%';
angleLB.style.height = '100%';
if(IsDarkTheme()){
    angleLB.style.borderLeft = '2px solid var(--color-light-1)';
    angleLB.style.borderBottom = '2px solid var(--color-light-1)';
}else{
    angleLB.style.borderLeft = '2px solid var(--color-dark-2)';
    angleLB.style.borderBottom = '2px solid var(--color-dark-2)';
}

let angleRB = document.createElement('div');
angleRB.style.width = '100%';
angleRB.style.height = '100%';
if(IsDarkTheme()){
    angleRB.style.borderRight = '2px solid var(--color-light-1)';
    angleRB.style.borderBottom = '2px solid var(--color-light-1)';
}else{
    angleRB.style.borderRight = '2px solid var(--color-dark-2)';
    angleRB.style.borderBottom = '2px solid var(--color-dark-2)';
}

fsB.append(angleLT,angleRT,angleLB,angleRB);
block.append(leftTime,predmet,progressBar,otsw,fsB);
rightBlock.prepend(block);

SpawnBlock()
function SpawnBlock(){
    let filterContent = document.querySelector('.filter-content');
    if(!filterContent){
        setTimeout(() => SpawnBlock(), 100);
        return;
    }
    filterContent.after(rightBlock);
}

id = undefined;
function move() {
    block.style.cursor = 'auto';
    fsB.style.opacity = '1';
    otsw.style.opacity = '1';
    clearTimeout(id);
    id = setTimeout(() => {
        block.style.cursor = 'none';
        fsB.style.opacity = '0';
        otsw.style.opacity = '0';
    },3000)
}


function fullSrcreen(){
    fs = !fs;
    if(fs){
        block.style.position = 'fixed';
        block.style.top = '0';
        block.style.left = '0';
        block.style.height = '100vh';
        block.style.width = '100vw';
        block.style.zIndex = '9999999';
        block.style.borderRadius = '0';

        leftTime.style.fontSize = '20vw';
        predmet.style.fontSize = '5vw';
        document.querySelector('body').style.overflowY = 'hidden';

        block.style.cursor = 'none';
        fsB.style.opacity = '0';
        otsw.style.opacity = '0';

        block.addEventListener('mousemove',move);

        var elem = document.querySelector("body");

        // Запрашиваем полноэкранный режим
        if (elem.requestFullscreen) {
          elem.requestFullscreen();
        } else if (elem.mozRequestFullScreen) { // для Firefox
          elem.mozRequestFullScreen();
        } else if (elem.webkitRequestFullscreen) { // для Chrome и Safari
          elem.webkitRequestFullscreen();
        }


    }else{
        block.style.position = 'relative';
        block.style.height = 'fit-content';
        block.style.width = '100%';
        block.style.zIndex = 'auto';
        block.style.borderRadius = '8px';

        clearTimeout(id);
        block.removeEventListener('mousemove',move);

        block.style.cursor = 'auto';
        fsB.style.opacity = '1';
        otsw.style.opacity = '1';

        leftTime.style.fontSize = '40px';
        predmet.style.fontSize = '15px';
        document.querySelector('body').style.overflowY = 'scroll';
        progressBar.style.height = '5px';

        // Выходим из полноэкранного режима
        if(document.exitFullscreen) {
           document.exitFullscreen();
         }else if (document.mozCancelFullScreen) { // для Firefox
           document.mozCancelFullScreen();
         } else if (document.webkitExitFullscreen) { // для Chrome и Safari
           document.webkitExitFullscreen();
         }
         setTimeout(() => {
            scroll2element(block);
         }, 500);
    }
}

let ts = +localStorage.getItem('ts') || 0;
let pairsList = [];
let l = true;
let mainID = undefined;
fill()
function fill() {
    let timetable = document.querySelectorAll('.timetable');
    if(!timetable.length){
        setTimeout(fill,100);
        return;
    }
    pairsList = [];
    Log('fill');
    
    
    let current = document.querySelector('.current');
    if(!current) {
        leftTime.textContent = '';
        predmet.textContent = '';
        progressBar.style.transform = `translateX(0%)`;
        progressBar.style.backgroundColor = 'var(--color-purple)';
        progressBar.style.boxShadow = '0 0 10px var(--color-purple)';
        return;
    }

    clearTimeout(mainID);
    
    if(l){
        scroll2element(current);
        l = !l;
    }
    
    let rows = current.querySelectorAll('.timetable-row');
    for(let i = 0; i<rows.length;i++){
        if(rows[i].querySelector('.empty') && rows[i].querySelector('.timetable-pair').childElementCount == 1) continue;

        rows[i].id = 'n'+i;

        let pari = rows[i].querySelectorAll('.timetable-discipline');
        let pariStr = [];
        for(let j of pari) pariStr.push(j.textContent);

        let pair = {id: 'n'+i,
                    n: rows[i].querySelector('.timetable-pair-number').textContent,
                    name: pariStr.join(' / '),
                    s: rows[i].querySelector('.timetable-call>div:first-child').textContent,
                    d: rows[i].querySelector('.timetable-call>div:last-child').textContent,
                    p: rows[i].querySelector('.timetable-call>div:nth-child(3)').textContent.replace('м','')
                }

        pairsList.push(pair);
    }
    main();
}



function main(){
    let q = false;

    const date = new Date();
    const hours = date.getHours();
    const minutes = date.getMinutes();
    const seconds = date.getSeconds();
    date.getDate

    let curtime = hours*3600 + minutes*60 + seconds;
    //let curtime = 14*3600 + 20*60 + 00;
    curtime += ts;

    for(let i = 0; i<pairsList.length;i++){
        if(curtime < time2int(pairsList[0].s+':00')){
            q = true;
            leftTime.textContent = int2time(time2int(pairsList[0].s+':00')-curtime);
            predmet.textContent = `До начала пар`;
            progressBar.style.transform = `translateX(0%)`;
            progressBar.style.backgroundColor = 'transparent';
            progressBar.style.boxShadow = '0 0 10px transparent';

        }

        if(curtime >= time2int(pairsList[i].s+':00') && curtime <= time2int(pairsList[i].d+':00')){
            q = true;
            leftTime.textContent = int2time(time2int(pairsList[i].d+':00')-curtime);
            predmet.textContent = `[${pairsList[i].n}] ${pairsList[i].name}`;

            if(document.getElementById(pairsList[i].id)){
                document.getElementById(pairsList[i].id).style.color = 'var(--color-cyan)';
            }

            let dl = time2int(pairsList[i].d+':00') - time2int(pairsList[i].s+':00');
            let pr = curtime - time2int(pairsList[i].s+':00');
            let procent = round((pr/dl)*100);
            progressBar.style.transform = `translateX(${procent-100}%)`;

            progressBar.style.backgroundColor = 'var(--color-cyan)';
            progressBar.style.boxShadow = '0 0 10px var(--color-cyan)';

        }else{
            if(document.getElementById(pairsList[i].id)){
                document.getElementById(pairsList[i].id).style.color = 'var(--white)';
            }
        }

        if(curtime >= time2int(pairsList[i].d+':00') && curtime <= time2int(pairsList[i].d+':00')+pairsList[i].p*60){
            q = true;
            leftTime.textContent = int2time(time2int(pairsList[i].d+':00')+pairsList[i].p*60-curtime);
            predmet.textContent = 'Перемена';
            //leftTime.onclick = () => open('https://youtube.com/shorts/HP1S4mrxOTI?feature=share');

            let dl =  pairsList[i].p*60;
            let pr = curtime - (time2int(pairsList[i].d+':00'));
            let procent = round((pr/dl)*100);
            progressBar.style.transform = `translateX(${procent-100}%)`;

            progressBar.style.backgroundColor = 'var(--color-green)';
            progressBar.style.boxShadow = '0 0 10px var(--color-green)';
        }

    }
    
    if(!q){
        leftTime.textContent = int2time(curtime);
        let day = date.getDate();
        let month = date.getMonth()+1;
        if(day < 10) day = '0'+day;
        if(month < 10) month = '0'+month;
        predmet.textContent = `${day}.${month}`;
        progressBar.style.transform = `translateX(0%)`;
        progressBar.style.backgroundColor = 'transparent';
        progressBar.style.boxShadow = '0 0 10px transparent';
    }
    mainID = setTimeout(main,1000);
}


function time2int(time){
    let t = time.split(':');

    const hours = Number(t[0]);
    const minutes = Number(t[1]);
    const seconds = Number(t[2]);

    return hours*3600 + minutes*60 + seconds;
}


function int2time(time){
    let hours = round(time/3600);
    let minutes = round((time - hours*3600)/60);
    let seconds = time - hours*3600 - minutes*60;

    if (hours < 10) hours = "0" + hours;
    if (minutes < 10) minutes = "0" + minutes;
    if (seconds < 10) seconds = "0" + seconds;

    return `${hours}:${minutes}:${seconds}`
}


function round(a){
    return a-a%1
}


function scroll2element(element) {
    if(!element) return;
    const rect = element.getBoundingClientRect();
    const scrollY = window.scrollY || window.pageYOffset;
    const offsetY = rect.top + scrollY;
    window.scrollTo({top: offsetY - window.innerHeight/2 + element.getClientRects()[0].height/2})
}