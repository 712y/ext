document.querySelector('html').style.scrollBehavior = 'smooth';

function IsDarkTheme() {
    return document.querySelector('head>link').href.indexOf('dark') != -1;
}



function changeWeek() {
    let seen = document.querySelectorAll('.seen');
    if(seen.length){
        setTimeout(changeWeek,100);
        return;
    }
    br();
    let current = document.querySelector('.current');
    if(!current) return;
    let rows = current.querySelectorAll('.timetable-row');
    for(let i = 0; i<rows.length;i++){
        if(rows[i].querySelector('.empty') && rows[i].querySelector('.timetable-pair').childElementCount == 1) continue;
        rows[i].id = 'n'+i;
    }
}


br()
function br(){
    let timetable = document.querySelectorAll('.timetable');
    if(!timetable.length){
        setTimeout(br,100);
        return;
    }

    
    Log('timetable ');
    
    

    for (let i = 0; i < timetable.length; i++) {
        
        timetable[i].classList.add('seen')
        timetable[i].style.overflow = 'hidden';
        timetable[i].style.height = 'fit-content';
        
        if(screen.availHeight>screen.availWidth){
            let p = timetable[i].querySelectorAll('.timetable-row');
            for(let j = 0; j<p.length;j++){ 
               if(p[j].querySelector('.empty') && p[j].querySelector('.timetable-pair').childElementCount == 1){
                   p[j].remove();
               }
            }
        }   
        if(!timetable[i].querySelector('.timetable-content').childElementCount) continue;
        timetable[i].querySelector('.timetable-row:last-child>.timetable-pair>.timetable-subgroup:last-child').style.borderRadius = '0 0 7px 0'
    }
    

    let current = document.querySelector('.current');
    if(current) {
        current.style.boxShadow = '0 0 10px var(--color-cyan)';
        current.id = 'cur';
        current.querySelector('.timetable-head').ondblclick = () => scroll2element(document.querySelector('.timeBlock'))
    };

    
    let control_grid  = document.querySelector('.control-grid');
    let s = control_grid.querySelectorAll('.input>select');
    for (let i = 0; i < s.length; i++) {
        s[i].onchange = () =>{
            changeWeek();
        }
    }

    

}
hint()
function hint() {
    let float_hint = document.querySelector('.timetable-hint');
    if(!float_hint){
        setTimeout(hint,100);
        return;
    }
    Log('hint ');
    float_hint.style.maxWidth = '100vw';
    float_hint.style.width = '380px';
}

function Log(text){
    console.log("%c " + 'ext' + " ", "font-weight:bold;background-color:" + 'royalblue' + ";color:white",text)
}

//dropdown_menu()
function dropdown_menu(){
    if(screen.availHeight>screen.availWidth) return;
    let dropDownMenu = document.querySelectorAll('.dropdown-menu');
    if (!dropDownMenu.length) {
        setTimeout(dropdown_menu,100);
        return;
    }
    Log('dropDownMenu');
    for (const i of dropDownMenu) {
        i.style.borderRadius = '8px';
        i.style.backgroundColor = 'transparent';
        i.style.backdropFilter = 'blur(7px) brightness(0.7)';
        i.style.border = '1px solid var(--color-cyan)';
        i.querySelector("a:first-child").style.borderRadius = '8px 8px 0 0';
        i.querySelector("a:last-child").style.borderRadius = '0 0 8px 8px';
    }
}
inputs();
function inputs(){
    let inputsGrid = document.querySelector('div.control-grid');
    let weekSelect = document.querySelector("div.control-grid > label:nth-child(3) > select");
    if(!weekSelect){
        setTimeout(inputs,100);
        return;
    }
    Log('inputsGrid');
    /**
     * @type{HTMLSelectElement}
     */
    let curvalue = weekSelect.value;
    let lab = document.createElement('label');
    lab.className = 'input';

    let buttonsGrid = document.createElement('div');
    buttonsGrid.style.display = 'grid';
    buttonsGrid.style.gridTemplateColumns = '1fr 1fr 1fr';
    buttonsGrid.style.width = '100%';
    buttonsGrid.style.height = '32px';
    buttonsGrid.style.fontSize = '1rem';
    buttonsGrid.style.fontWeight = 'normal !important';
    buttonsGrid.style.gap = '5px'
    

    let buttonM = document.createElement('button');
    buttonM.textContent = '<<<';
    if(IsDarkTheme()){
        buttonM.style.color = 'var(--color-light-2)';
        buttonM.style.backgroundColor = 'var(--color-dark-2)';
        buttonM.style.border = '1px solid var(--color-dark)';
    }else{
        buttonM.style.border = '1px solid var(--color-light-2)';
        buttonM.style.backgroundColor = 'var(--color-light-1)';
        buttonM.style.color = 'var(--color-dark-2)';
    }
    buttonM.style.borderRadius = '8px';
    buttonM.onclick = () => {
        weekSelect.value = +weekSelect.value-604800000;
        weekSelect.dispatchEvent(new Event('change')); 
    }

    let buttonB = document.createElement('button');
    buttonB.textContent = '*';
    if(IsDarkTheme()){
        buttonB.style.color = 'var(--color-light-2)';
        buttonB.style.backgroundColor = 'var(--color-dark-2)';
        buttonB.style.border = '1px solid var(--color-dark)';
    }else{
        buttonB.style.border = '1px solid var(--color-light-2)';
        buttonB.style.backgroundColor = 'var(--color-light-1)';
        buttonB.style.color = 'var(--color-dark-2)';
    }
    buttonB.style.borderRadius = '8px';
    buttonB.onclick = () => {
        if(document.querySelector('.current')) return;
        weekSelect.value = curvalue;
        weekSelect.dispatchEvent(new Event('change')); 
    }

    let buttonP = document.createElement('button');
    buttonP.textContent = '>>>';
    if(IsDarkTheme()){
        buttonP.style.color = 'var(--color-light-2)';
        buttonP.style.backgroundColor = 'var(--color-dark-2)';
        buttonP.style.border = '1px solid var(--color-dark)';
    }else{
        buttonP.style.border = '1px solid var(--color-light-2)';
        buttonP.style.backgroundColor = 'var(--color-light-1)';
        buttonP.style.color = 'var(--color-dark-2)';
    }
    buttonP.style.borderRadius = '8px';
    buttonP.onclick = () => {
        weekSelect.value = +weekSelect.value+604800000;
        weekSelect.dispatchEvent(new Event('change')); 
    }

    let placeholder = document.createElement('span');
    placeholder.className = 'placeholder';
    placeholder.textContent = 'туда-сюда';

    buttonsGrid.append(buttonM,buttonB,buttonP);
    lab.append(buttonsGrid,placeholder);
    inputsGrid.append(lab);

    for (const i of [buttonM,buttonB,buttonP]) {
        i.onmousedown = () => i.style.border = '1px solid var(--color-cyan)';
        i.onmouseup = () => {
            if(IsDarkTheme()){
                i.style.border = '1px solid var(--color-dark)';
            }else{
                i.style.border = '1px solid var(--color-light-2)';
            }
        }
    }
}